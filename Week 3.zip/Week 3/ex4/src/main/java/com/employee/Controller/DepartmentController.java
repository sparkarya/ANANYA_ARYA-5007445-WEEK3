package com.employee.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.employee.dao.DepartmentRepository;
import com.employee.entities.Department;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("/api/Department")
public class DepartmentController {

    @Autowired
    private DepartmentRepository departmentRepository;

    // Create
    @PostMapping("/add")
    public ResponseEntity<Department> addDepartment(@RequestBody Department department) {
        Department addDepartment = departmentRepository.save(department);
        return ResponseEntity.ok(addDepartment);
    }


    // Read
    @GetMapping("/{id}")
    public ResponseEntity<Department> getBookById(@PathVariable int id) {
        Optional<Department> Department = departmentRepository.findById(id);
        return Department.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping
    public List<Department> getAllBooks() {
        return departmentRepository.findAll();
    }

    //Update
    @PutMapping("/{id}")
    public ResponseEntity<Department> updateDepartment(@PathVariable int id, @RequestBody Department Department) {
        if (!departmentRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        Department.setId(id);
        Department updatedBook = departmentRepository.save(Department);
        return ResponseEntity.ok(updatedBook);
    }


    // Delete
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDepartment(@PathVariable int id) {
        if (!departmentRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        departmentRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
    
}
