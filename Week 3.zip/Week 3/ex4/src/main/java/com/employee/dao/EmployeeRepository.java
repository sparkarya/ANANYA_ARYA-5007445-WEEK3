package com.employee.dao;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.employee.entities.Employee;
import com.employee.entities.Department;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

    List<Employee> findByDepartment(Department department);

    Employee findByEmail(String email);
}


// findByDepartment(Department department): This method will find all employees associated with a specific Department entity.

// findByEmail(String email): This method will find an employee by their email.