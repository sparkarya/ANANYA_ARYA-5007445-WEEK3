package com.example.entities;

import org.springframework.beans.factory.annotation.Value;

public interface employeeFullNameProjection {
    @Value("#{target.firstName + ' ' + target.lastName}")
    String getFullName();
}
