package com.example.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.entities.Employee;
import com.example.entities.employeeFullNameProjection;
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

    List<employeeFullNameProjection> findAllProjectedBy();
}
